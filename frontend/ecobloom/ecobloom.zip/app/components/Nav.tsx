export default function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-sage-950/10 bg-paper/85 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <a href="#top" className="flex items-center gap-2 font-display text-lg font-medium">
          <span
            aria-hidden
            className="inline-block h-2.5 w-2.5 rounded-full bg-pink-400"
            style={{ boxShadow: "0 0 8px #e88aa6" }}
          />
          Ecobloom
        </a>
        <nav className="hidden gap-8 font-mono text-xs uppercase tracking-wide text-sage-700 sm:flex">
          <a href="#how" className="hover:text-sage-950">
            How it works
          </a>
          <a href="#stages" className="hover:text-sage-950">
            Grow stages
          </a>
          <a href="#app" className="hover:text-sage-950">
            App
          </a>
          <a href="#roadmap" className="hover:text-sage-950">
            Roadmap
          </a>
        </nav>
        <a
          href="#waitlist"
          className="rounded-full bg-sage-950 px-4 py-2 font-mono text-xs uppercase tracking-wide text-paper transition hover:bg-pink-700"
        >
          Join waitlist
        </a>
      </div>
    </header>
  );
}

# Ecobloom

Marketing site for Ecobloom — a flower-shaped lamp that dims itself when
you leave a room, and blooms or wilts with your energy habits over time.

Built with Next.js (App Router) + TypeScript + Tailwind CSS v4, configured
as a fully static export so it can be hosted on Cloudflare Pages with no
server runtime.

## Run it locally (VS Code)

Requires [Node.js](https://nodejs.org) 18.18+ (20 LTS recommended).

```bash
npm install
npm run dev
```

Open http://localhost:3000. The homepage is `app/page.tsx`, sections live
in `app/components/`, and the interactive flower is
`app/components/PixelFlower.tsx`.

```bash
npm run build   # outputs a static site to /out
```

## Deploy to Cloudflare Pages (via GitHub) — no build config needed

1. **Push this folder to a new GitHub repo.**
   ```bash
   git init
   git add .
   git commit -m "Ecobloom site"
   git branch -M main
   git remote add origin https://github.com/<you>/ecobloom.git
   git push -u origin main
   ```

2. **In the Cloudflare dashboard:** Workers & Pages → Create → Pages →
   Connect to Git → pick the `ecobloom` repo.

3. **Build settings** (Cloudflare auto-detects Next.js, but confirm):
   - Framework preset: `Next.js (Static HTML Export)`
   - Build command: `npm run build`
   - Build output directory: `out`

4. Click **Save and Deploy**. Every future push to `main` redeploys
   automatically — that's the entire pipeline.

5. (Optional) Add a custom domain under the Pages project's **Custom
   domains** tab once it's live.

## Before you launch

- **Waitlist form**: `app/components/Waitlist.tsx` captures an email in
  local state only — there's no backend in a static export. Wire the
  `handleSubmit` function to a form service ([Formspree](https://formspree.io),
  [Resend](https://resend.com)) or a
  [Cloudflare Pages Function](https://developers.cloudflare.com/pages/functions/)
  before launch.
- **Metadata**: update the title/description in `app/layout.tsx`, and add
  an OG image + favicon in `app/` (replace `app/favicon.ico`).
- **Fonts**: the site uses Google Fonts (Fraunces, Inter, IBM Plex Mono)
  via `next/font/google`, fetched automatically at build time — no
  action needed, just make sure the build step has normal internet
  access (Cloudflare's build servers do).

## Project structure

```
app/
  layout.tsx          fonts + page metadata
  page.tsx             assembles all sections
  globals.css          design tokens (colors, fonts) as CSS variables
  components/
    Nav.tsx
    Hero.tsx            headline + interactive demo
    HeroDemo.tsx         slider that drives the pixel flower
    PixelFlower.tsx       the signature bloom/wilt SVG element
    HowItWorks.tsx        sense -> dim -> grow
    GrowStages.tsx         bud / bloom / wilt / shrivel (v2 hardware)
    Features.tsx            notifications, habit coach, weekly digest
    Roadmap.tsx
    Waitlist.tsx
    Footer.tsx
```
